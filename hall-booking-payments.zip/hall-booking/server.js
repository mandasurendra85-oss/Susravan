require('dotenv').config();
const express = require('express'), fs = require('fs'), crypto = require('crypto'), path = require('path');
const app = express();
const PORT = process.env.PORT || 3000, BASE = process.env.BASE_URL || `http://localhost:${PORT}`;
const PROVIDER = (process.env.PAYMENT_PROVIDER || 'stripe').toLowerCase();
const CUR = (process.env.CURRENCY || 'USD').toUpperCase();

// Prices live on the server so customers cannot change what they pay.
const HALLS = {
  grand:  { name: 'Grand Ballroom',   cap: 400, price: 2500 },
  garden: { name: 'Garden Pavilion',  cap: 200, price: 1400 },
  lounge: { name: 'Executive Lounge', cap: 80,  price: 700 }
};
const CATER = [0, 12, 22];
const SLOTS = ['Morning (8am–2pm)', 'Evening (5pm–11pm)'];
const HOLD = { online: 30 * 60e3, bank: 48 * 3600e3, venue: Infinity };

const DB = path.join(__dirname, 'bookings.json');
const read = () => { try { return JSON.parse(fs.readFileSync(DB)); } catch { return []; } };
const write = d => fs.writeFileSync(DB, JSON.stringify(d, null, 2));
const find = ref => read().find(b => b.ref === ref);
const active = b => b.status === 'confirmed' || (b.status === 'pending' && Date.now() - b.created < HOLD[b.method]);
const dueNow = b => (b.paid > 0 ? b.total - b.paid : b.payNow);

const stripe = PROVIDER === 'stripe' && process.env.STRIPE_SECRET_KEY ? require('stripe')(process.env.STRIPE_SECRET_KEY) : null;
const rzp = PROVIDER === 'razorpay' && process.env.RAZORPAY_KEY_ID
  ? new (require('razorpay'))({ key_id: process.env.RAZORPAY_KEY_ID, key_secret: process.env.RAZORPAY_KEY_SECRET }) : null;

function markPaid(ref, amount, payId) {
  const d = read(), b = d.find(x => x.ref === ref);
  if (!b || b.payments.includes(payId)) return; // ignore duplicate webhooks
  b.payments.push(payId);
  b.paid = Math.min(b.total, b.paid + amount);
  b.status = 'confirmed';
  write(d);
}

// Stripe webhook needs the raw body, so it is registered before express.json().
app.post('/api/stripe-webhook', express.raw({ type: 'application/json' }), (req, res) => {
  if (!stripe) return res.sendStatus(404);
  let ev;
  try { ev = stripe.webhooks.constructEvent(req.body, req.headers['stripe-signature'], process.env.STRIPE_WEBHOOK_SECRET); }
  catch { return res.status(400).send('Bad signature'); }
  if (ev.type === 'checkout.session.completed' && ev.data.object.payment_status === 'paid') {
    const s = ev.data.object;
    markPaid(s.metadata.ref, s.amount_total / 100, s.id);
  }
  res.json({ received: true });
});

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.get('/api/config', (req, res) => res.json({ provider: PROVIDER, currency: CUR }));

app.get('/api/availability', (req, res) =>
  res.json(read().filter(active).map(b => ({ hall: b.hall, date: b.date, slot: b.slot }))));

app.post('/api/bookings', (req, res) => {
  const q = req.body || {}, h = HALLS[q.hall];
  const g = parseInt(q.guests, 10), c = CATER[parseInt(q.catering, 10)];
  const err = !h ? 'Unknown hall'
    : !SLOTS.includes(q.slot) ? 'Unknown time slot'
    : !/^\d{4}-\d\d-\d\d$/.test(q.date || '') || q.date < new Date().toISOString().slice(0, 10) ? 'Choose a future date'
    : !(g >= 1 && g <= h.cap) ? `Guests must be between 1 and ${h.cap}`
    : c === undefined ? 'Unknown catering option'
    : !String(q.name || '').trim() ? 'Name is required'
    : !/^\S+@\S+\.\S+$/.test(q.email || '') ? 'A valid email is required'
    : !HOLD[q.method] ? 'Unknown payment method' : '';
  if (err) return res.status(400).json({ error: err });
  const d = read();
  if (d.some(b => b.hall === q.hall && b.date === q.date && b.slot === q.slot && active(b)))
    return res.status(409).json({ error: 'That slot was just booked. Choose another.' });
  const total = h.price + g * c, payNow = q.plan === 'full' ? total : Math.round(total * 0.3);
  const b = {
    ref: 'HB-' + crypto.randomBytes(4).toString('hex').toUpperCase(),
    hall: q.hall, date: q.date, slot: q.slot, ev: String(q.ev || '').slice(0, 40), guests: g,
    name: String(q.name).trim().slice(0, 80), phone: String(q.phone || '').slice(0, 30), email: q.email,
    total, payNow, method: q.method, paid: 0, payments: [],
    status: q.method === 'venue' ? 'confirmed' : 'pending', created: Date.now()
  };
  d.push(b); write(d);
  res.json({ ref: b.ref, method: b.method, total, payNow, bank: process.env.BANK_DETAILS || '' });
});

app.post('/api/lookup', (req, res) => {
  const refs = Array.isArray(req.body.refs) ? req.body.refs : [];
  res.json(read().filter(b => refs.includes(b.ref)).map(b => ({
    ref: b.ref, hallName: HALLS[b.hall].name, date: b.date, slot: b.slot, ev: b.ev, guests: b.guests,
    total: b.total, paid: b.paid, method: b.method, due: dueNow(b),
    status: b.status === 'pending' && !active(b) ? 'expired' : b.status
  })));
});

function payable(req, res) {
  const b = find(req.params.ref);
  if (!b || b.method !== 'online') { res.status(400).json({ error: 'Booking not found' }); return null; }
  if (!active(b)) { res.status(400).json({ error: 'The hold on this date expired. Please book again.' }); return null; }
  if (dueNow(b) <= 0) { res.status(400).json({ error: 'Nothing left to pay' }); return null; }
  return b;
}

app.post('/api/pay/:ref/stripe', async (req, res) => {
  try {
    const b = stripe && payable(req, res); if (!b) return stripe ? undefined : res.status(400).json({ error: 'Stripe is not configured' });
    const s = await stripe.checkout.sessions.create({
      mode: 'payment', customer_email: b.email, metadata: { ref: b.ref },
      line_items: [{ quantity: 1, price_data: { currency: CUR.toLowerCase(), unit_amount: Math.round(dueNow(b) * 100),
        product_data: { name: `${HALLS[b.hall].name} – ${b.date} (${b.slot})` } } }],
      success_url: `${BASE}/?paid=${b.ref}`, cancel_url: `${BASE}/?cancelled=${b.ref}`
    });
    res.json({ url: s.url });
  } catch (e) { console.error(e); res.status(500).json({ error: 'Payment could not be started' }); }
});

app.post('/api/pay/:ref/razorpay', async (req, res) => {
  try {
    const b = rzp && payable(req, res); if (!b) return rzp ? undefined : res.status(400).json({ error: 'Razorpay is not configured' });
    const amount = Math.round(dueNow(b) * 100);
    const o = await rzp.orders.create({ amount, currency: CUR, receipt: b.ref });
    const d = read(), x = d.find(y => y.ref === b.ref); x.rzpOrder = o.id; x.rzpAmount = amount; write(d);
    res.json({ orderId: o.id, amount, currency: CUR, keyId: process.env.RAZORPAY_KEY_ID, name: b.name, email: b.email, phone: b.phone });
  } catch (e) { console.error(e); res.status(500).json({ error: 'Payment could not be started' }); }
});

app.post('/api/pay/:ref/razorpay/verify', (req, res) => {
  const b = find(req.params.ref), p = req.body || {};
  if (!b || !b.rzpOrder || !p.razorpay_payment_id) return res.status(400).json({ error: 'Invalid payment' });
  const sig = crypto.createHmac('sha256', process.env.RAZORPAY_KEY_SECRET).update(b.rzpOrder + '|' + p.razorpay_payment_id).digest('hex');
  const got = String(p.razorpay_signature || '');
  if (got.length !== sig.length || !crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(got)))
    return res.status(400).json({ error: 'Payment verification failed' });
  markPaid(b.ref, b.rzpAmount / 100, p.razorpay_payment_id);
  res.json({ ok: true });
});

app.listen(PORT, () => console.log(`Hall booking running at ${BASE} (payments: ${PROVIDER})`));
