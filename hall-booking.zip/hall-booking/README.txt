Function Hall Booking App
=========================
Open index.html in any browser. No install or server needed.

- Bookings are saved in the browser (localStorage) on that device only.
- Payment is a demo checkout: no real charges. To accept real payments,
  connect a gateway (Stripe, Razorpay, etc.) through a backend.
- Edit the HALLS array in the script section to change halls and prices.
